# Tienda-online-php-mvc-y-mysql
![tienda](https://github.com/VidaInformatico/Tienda-online-PHP-mvc-y-Mysql/assets/71534078/13df062f-c63d-4ca7-9437-d1bcc5acf4a9)

## Configuración

Instalación de Phpmailer

```bash
  composer install
```
    
## Credenciales de acceso
- Email: angelsifuentes2580@gmail.com
- Clave: 12345
