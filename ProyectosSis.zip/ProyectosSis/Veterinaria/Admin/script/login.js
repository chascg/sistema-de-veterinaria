document.addEventListener("DOMContentLoaded", function() {
    const loginForm = document.getElementById("admin-login");

    loginForm.addEventListener("submit", function(event) {
        event.preventDefault();

        const credentials = {
            username: document.getElementById("username").value,
            password: document.getElementById("password").value
        };

        fetch('/api/admin/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(credentials)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Login exitoso');
                window.location.href = '/admin/dashboard'; // Redirige al panel de administrador
            } else {
                alert('Credenciales incorrectas');
            }
        })
        .catch(error => {
            console.error('Error al iniciar sesión:', error);
        });
    });
});
