// Ruta para servir el panel de administración
app.get('/admin/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, '../../admin-dashboard.html'));
});
