<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Puente servicios veterinaria</title>

    <script src="https://kit.fontawesome.com/c1df782baf.js"></script>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-thin-rounded/css/uicons-thin-rounded.css'>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>
    <link rel="stylesheet" href="Inicio/css/styleUsuario.css">

</head>
<body> 

    <header>
        
        <div class="logo"><img src="Inicio/css/images/logo vet puente.jpeg" alt="Veterinaria Los Dos Becerros"></div>

        <nav class="navbar">
            <a href='inicio.php'>Inicio</a>
            <a href='Desc.php'>Descripción</a>
            <a href="http://localhost/ProyectosSis/Tienda-online/">Tienda</a>
            <a href='https://www.seccionamarilla.com.mx/informacion/puente-vazquez-victor-manuel-mvz/medicos-veterinarios-zootecnistas/tamaulipas/ciudad-mante/moderna/3396647'>Contacto</a>
        </nav>

    </header>

    <!-- header section ended -->

    <!-- Home section started -->

    <div class="main-home">

        <div class="home">
            <div class="home-left-content">
                <span>Puente servicios veterinaria</span>
                <h2>Tu mascota,<br> nuestro compromiso de vida.</h2>
                <p class="lorem">Con más de 10 años de dedicación, ofrecemos un cuidado integral y especializado, 
                    donde cada mascota recibe atención profesional y un trato lleno de cariño en cada visita.
                </p>

                <div class="home-feelings">
                    <button class="send-button" id="send-btn">Agendar una cita</button>
                </div>
            </div>

            <div class="home-right-content">
                <img src="Inicio/css/images/hero2.png" alt="Cuidado de mascotas">
            </div>
        </div>

    </div>

    <!-- home section ends -->

    <!-- Technology section started -->

    <div class="technology">
        <div class="main-technology">
            
            <div class="inner-technology">
                <span></span>
                <i class="fi fi-tr-hands-heart"></i>
                <h2>Calidad y Seguridad</h2>
                <p>Nuestros veterinarios utilizan tecnología y emplean un equipo de verdaderos expertos para el cuidado de tu mascota.</p>
            </div>

            <div class="inner-technology">
                <span></span>
                <i class="fi fi-rr-doctor"></i>
                <h2>Atención Médica</h2>
                <p>En nuestra clínica, tu mascota recibirá atención médica de calidad, con diagnóstico preciso y tratamientos efectivos.</p>
            </div>

            <div class="inner-technology">
                <span></span>
                <i class="fi fi-tr-user-md"></i>
                <h2>Consultas Veterinarias</h2>
                <p>Contamos con consultas especializadas para cualquier necesidad médica de tu mascota, desde chequeos regulares hasta emergencias.</p>
            </div>
        </div>
    </div>

    <!-- Technology section ends -->

    <!-- About us section started -->

    <div class="main-about">

        <div class="about-heading">Acerca de nosotros</div>

        <div class="inner-main-about">
            <div class="about-inner-content-left">
                <img src="Inicio/css/images/clinica-veterinaria-en-lorca.jpg" alt="Veterinarios cuidando mascotas">
            </div>

            <div class="about-inner-content">
                <div class="about-right-content">
                    <h2>Somos un referente en cuidado veterinario</h2>
                    <p>Con más de 10 años de experiencia, ofrecemos atención especializada y un enfoque integral para la salud de tu mascota.</p>
                    <p class="aboutsec-content">
                        Nuestra clínica veterinaria ha crecido para ofrecer instalaciones para el tratamiento de enfermedades, cuidados preventivos y emergencias. 
                        Nos enorgullece ser uno de los centros más calificados con más de 10 años de experiencia en atención veterinaria.
                    </p>
                    <div class="right-icons">
                        <div id="menu-bars" class="fas fa-bars"></div>
                        <div class="btn"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- About us section ends -->

    <!-- footer -->

    <footer class="footer">
        <div class="container container-footer">
            <div class="menu-footer">
                <div class="contact-info">
                    <p class="title-footer">Información de Contacto</p>
                    <ul>
                        <li>Dirección: Calle , 123</li>
                        <li>Teléfono: 000-000-0000</li>
                        <li>Dr. Veterinario: Isidro Quintero Torres</li>
                        <li>Email: dos_becerros@support.com</li>
                    </ul>
                    <div class="social-icons">
                        <span class="facebook">
                            <i class="fa-brands fa-facebook-f"></i>
                        </span>
                        <span class="twitter">
                            <i class="fa-brands fa-twitter"></i>
                        </span>
                        <span class="instagram">
                            <i class="fa-brands fa-instagram"></i>
                        </span>
                    </div>
                </div>

                <div class="information">
                    <p class="title-footer">Información</p>
                    <ul>
                        <li><a href="#">Acerca de Nosotros</a></li>
                        <li><a href="#">Información de Pagos</a></li>
                        <li><a href="#">Políticas de Privacidad</a></li>
                        <li><a href="#">Términos y Condiciones</a></li>
                        <li><a href="#">Contáctanos</a></li>
                    </ul>
                </div>

                <div class="my-account">
                    <p class="title-footer">Mi cuenta</p>
                    <ul>
                        <li><a href="#">..</a></li>
                        <li><a href="#">..</a></li>
                        <li><a href="#">..</a></li>
                        <li><a href="#">..</a></li>
                    </ul>
                </div>

                <div class="newsletter">
                    <p class="title-footer">Suscríbete a nuestro boletín</p>
                    <div class="content">
                        <p>
                            Mantente al día con las novedades y promociones de Veterinaria Los Dos Becerros.
                        </p>
                    </div>
                </div>
            </div>

            <div class="copyright">
                <p>Puente servicios veterinaria</p>
                <img src="productos/css/img/payment.png" alt="Métodos de pago">
            </div>
        </div>
    </footer>

    <script src="https://kit.fontawesome.com/81581fb069.js" crossorigin="anonymous"></script>
    <script src="Inicio/js/script.js"></script>

</body>
</html>