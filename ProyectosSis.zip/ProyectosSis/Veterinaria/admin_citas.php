<?php
include 'conexion.php';

// Eliminar cita
if (isset($_GET['eliminar'])) {
    $id_cita = $_GET['eliminar'];
    $sql = "DELETE FROM citas WHERE id_cita = $id_cita";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Cita eliminada correctamente');</script>";
    } else {
        echo "<script>alert('Error al eliminar la cita: " . $conn->error . "');</script>";
    }
}

// Actualizar cita
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['actualizar'])) {
    $id_cita = $_POST['id_cita'];
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $nombre_dueno = $_POST['nombre_dueno'];
    $telefono = $_POST['telefono'];
    $especie = $_POST['especie'];
    $nombre_animal = $_POST['nombre_animal'];
    $edad_animal = $_POST['edad_animal'];
    $raza = $_POST['raza'];
    $descripcion = $_POST['descripcion'];

    $sql = "UPDATE citas SET 
            fecha='$fecha', 
            hora='$hora', 
            nombre_dueno='$nombre_dueno', 
            telefono='$telefono', 
            especie='$especie', 
            nombre_animal='$nombre_animal', 
            edad_animal=$edad_animal, 
            raza='$raza', 
            descripcion='$descripcion'
            WHERE id_cita = $id_cita";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Cita actualizada correctamente');</script>";
    } else {
        echo "<script>alert('Error al actualizar la cita: " . $conn->error . "');</script>";
    }
}

// Consultar citas
$sql = "SELECT * FROM citas";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vista Administrador - Gestión de Citas</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .btn {
            padding: 5px 10px;
            text-decoration: none;
            color: white;
            border-radius: 5px;
            margin-right: 5px;
        }
        .btn-eliminar {
            background-color: red;
        }
        .btn-editar {
            background-color: orange;
        }
    </style>
</head>
<body>
    <h1>Vista de Administrador - Gestión de Citas</h1>

    <!-- Tabla para mostrar citas -->
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Fecha</th>
                <th>Hora</th>
                <th>Dueño</th>
                <th>Teléfono</th>
                <th>Especie</th>
                <th>Animal</th>
                <th>Edad</th>
                <th>Raza</th>
                <th>Descripción</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id_cita']; ?></td>
                    <td><?php echo $row['fecha']; ?></td>
                    <td><?php echo $row['hora']; ?></td>
                    <td><?php echo $row['nombre_dueno']; ?></td>
                    <td><?php echo $row['telefono']; ?></td>
                    <td><?php echo $row['especie']; ?></td>
                    <td><?php echo $row['nombre_animal']; ?></td>
                    <td><?php echo $row['edad_animal']; ?></td>
                    <td><?php echo $row['raza']; ?></td>
                    <td><?php echo $row['descripcion']; ?></td>
                    <td>
                        <a class="btn btn-editar" href="admin_citas.php?editar=<?php echo $row['id_cita']; ?>">Editar</a>
                        <a class="btn btn-eliminar" href="admin_citas.php?eliminar=<?php echo $row['id_cita']; ?>" onclick="return confirm('¿Estás seguro de eliminar esta cita?')">Eliminar</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <!-- Formulario para editar citas -->
    <?php if (isset($_GET['editar'])) {
        $id_cita = $_GET['editar'];
        $sql = "SELECT * FROM citas WHERE id_cita = $id_cita";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
    ?>
        <h2>Editar Cita</h2>
        <form method="POST" action="admin_citas.php">
            <input type="hidden" name="id_cita" value="<?php echo $row['id_cita']; ?>">
            <input type="date" name="fecha" value="<?php echo $row['fecha']; ?>" required>
            <input type="time" name="hora" value="<?php echo $row['hora']; ?>" required>
            <input type="text" name="nombre_dueno" value="<?php echo $row['nombre_dueno']; ?>" required>
            <input type="text" name="telefono" value="<?php echo $row['telefono']; ?>" required>
            <input type="text" name="especie" value="<?php echo $row['especie']; ?>" required>
            <input type="text" name="nombre_animal" value="<?php echo $row['nombre_animal']; ?>" required>
            <input type="number" name="edad_animal" value="<?php echo $row['edad_animal']; ?>" required>
            <input type="text" name="raza" value="<?php echo $row['raza']; ?>">
            <textarea name="descripcion" required><?php echo $row['descripcion']; ?></textarea>
            <button type="submit" name="actualizar">Actualizar Cita</button>
        </form>
    <?php } ?>

</body>
</html>
