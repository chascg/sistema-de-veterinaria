<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Puente servicios veterinaria</title>

    <script src="https://kit.fontawesome.com/c1df782baf.js"></script>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-thin-rounded/css/uicons-thin-rounded.css'>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>
    <link rel="stylesheet" href="Cita/Citas/css/styles.css">
    

</head>

<header>
        
  <div class="logo"><img src="images/logo3.png" alt=""></div>
  <nav class="navbar">
  <a href='inicio.php'>Inicio</a>
            <a href='Desc.php'>Descripción</a>
            <a href="http://localhost/ProyectosSis/Tienda-online/">Tienda</a>
            <a href='https://www.seccionamarilla.com.mx/informacion/puente-vazquez-victor-manuel-mvz/medicos-veterinarios-zootecnistas/tamaulipas/ciudad-mante/moderna/3396647'>Contacto</a>
        </nav>

</header>

<section id="citas">

  <h2>Agenda nueva cita</h2>
  <form id="form-cita" action="agendar_cita.php" method="POST">
    <input type="date" name="fecha" required>
    <input type="time" name="hora" required min="09:00" max="19:00">
    <input type="text" name="nombre_dueno" placeholder="Nombre del dueño" required>
    <input type="text" name="telefono" placeholder="Teléfono" required>
    <input type="text" name="especie" placeholder="Especie (ej. perro, gato)" required>
    <input type="text" name="nombre_animal" placeholder="Nombre del animal" required>
    <input type="number" name="edad_animal" placeholder="Edad del animal en años" required>
    <input type="text" name="raza" placeholder="Raza">
    <textarea name="descripcion" placeholder="Descripción de la cita" required></textarea>
    <button type="submit">Agendar cita</button>
</form>

  <script src="Cita/Citas/script.js"></script>
</section>