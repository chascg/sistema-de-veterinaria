<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vital Control</title>

    <script src="https://kit.fontawesome.com/c1df782baf.js"></script>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-thin-rounded/css/uicons-thin-rounded.css'>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>
    <link rel="stylesheet" href="Cita/Citas/css/styles.css">
    

</head>

<header>
        
  <div class="logo"><img src="images/logo3.png" alt=""></div>

  <nav class="navbar">
  <a href='inicio.php'>Inicio</a>
            <a href='Desc.php'>Descripción</a>
            <a href="http://localhost/ProyectosSis/Tienda-online/">Tienda</a>
            <a href='https://www.seccionamarilla.com.mx/informacion/puente-vazquez-victor-manuel-mvz/medicos-veterinarios-zootecnistas/tamaulipas/ciudad-mante/moderna/3396647'>Contacto</a>
        </nav>
  </nav>

</header>