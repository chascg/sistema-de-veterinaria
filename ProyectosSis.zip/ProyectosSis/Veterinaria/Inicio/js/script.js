let menubar = document.querySelector('#menu-bars');
let navbar  = document.querySelector('.navbar');

menubar.onclick = () =>{
    menubar.classList.toggle('fa-times');
    navbar.classList.toggle('active')
}

const sendButton = document.getElementById("send-btn");
const feelingsInput = document.getElementById("feelings-input");

sendButton.addEventListener('click', function() {
    // Abre una nueva pestaña con el archivo especificado
    window.location.href = 'http://localhost/ProyectosSis/Veterinaria/citas.php';
});


function toggleTooltip(licenseId) {
    const tooltip = document.getElementById(licenseId);
    const isVisible = tooltip.style.visibility === 'visible';
    tooltip.style.visibility = isVisible ? 'hidden' : 'visible';
    tooltip.style.opacity = isVisible ? 0 : 1;
}

function showTooltip(id) {
    const tooltip = document.getElementById(id);
    const isVisible = tooltip.style.visibility === "visible";

    if (isVisible) {
        tooltip.style.visibility = "hidden";
        tooltip.style.opacity = 0;
    } else {
        tooltip.style.visibility = "visible";
        tooltip.style.opacity = 1;
    }
}

