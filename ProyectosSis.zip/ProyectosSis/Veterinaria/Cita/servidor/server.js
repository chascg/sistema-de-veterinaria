const express = require('express');
const path = require('path');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const app = express();

// Configuración del puerto
const PORT = process.env.PORT || 3000;

// Middleware para leer JSON en solicitudes POST
app.use(bodyParser.json());

// Middleware para servir archivos estáticos desde la carpeta principal 'Veterinaria'
app.use(express.static(path.join(__dirname, '../../')));

// Conexión a la base de datos
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Reemplaza 'root' con tu usuario de MySQL si es diferente
    password: '', // Reemplaza con tu contraseña de MySQL si la tienes configurada
    database: 'veterinaria_db'
});

// Conectar a la base de datos
db.connect((err) => {
    if (err) {
        console.log('Error al conectar a la base de datos:', err);
    } else {
        console.log('Conectado a la base de datos MySQL');
    }
});

// Ruta para la página de inicio
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../../inicio.html'));
});

// Ruta para 'Citas.html'
app.get('/citas', (req, res) => {
    res.sendFile(path.join(__dirname, '../../Citas.html'));
});

// Ruta para agendar citas (POST request)
app.post('/api/citas', (req, res) => {
    const { fecha, hora, nombreDueno, telefono, especie, nombreAnimal, edadAnimal, raza, descripcion } = req.body;

    if (!fecha || !hora || !nombreDueno || !telefono || !especie || !nombreAnimal || !edadAnimal || !descripcion) {
        return res.status(400).send('Todos los campos son requeridos');
    }

    const cita = { fecha, hora, nombreDueno, telefono, especie, nombreAnimal, edadAnimal, raza, descripcion };

    const sql = 'INSERT INTO citas SET ?';
    db.query(sql, cita, (err, result) => {
        if (err) {
            console.log(err);
            res.status(500).send('Error al guardar la cita');
        } else {
            res.status(200).send('Cita agendada con éxito');
        }
    });
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor escuchando en el puerto ${PORT}`);
});

// Ruta de login para administrador
app.post('/api/admin/login', (req, res) => {
    const { username, password } = req.body;

    // Validar credenciales (esto es un ejemplo sencillo, deberías usar un hash seguro y almacenarlo en la base de datos)
    if (username === 'admin' && password === 'admin123') {
        // Generar una respuesta simulando una autenticación exitosa
        res.status(200).send({ success: true, message: 'Login exitoso' });
    } else {
        res.status(401).send({ success: false, message: 'Credenciales incorrectas' });
    }
});

