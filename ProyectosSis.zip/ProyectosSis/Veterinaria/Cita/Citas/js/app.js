document.getElementById("form-cita").addEventListener("submit", function(event) {
  event.preventDefault();

  const cita = {
    fecha: document.getElementById("fecha").value,
    hora: document.getElementById("hora").value,
    nombreDueno: document.getElementById("nombre-dueno").value,
    telefono: document.getElementById("telefono").value,
    especie: document.getElementById("especie").value,
    nombreAnimal: document.getElementById("nombre-animal").value,
    edadAnimal: document.getElementById("edad-animal").value,
    raza: document.getElementById("raza").value,
    descripcion: document.getElementById("descripcion").value,
    foto: document.getElementById("foto").files[0].name // Solo almacenaremos el nombre del archivo por ahora
  };

  console.log("Cita agendada:", cita);
  alert("Cita agendada con éxito!");

  // Aquí se puede enviar la cita al backend o a la base de datos
});