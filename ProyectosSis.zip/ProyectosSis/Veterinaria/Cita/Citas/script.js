document.addEventListener("DOMContentLoaded", function() {
    const formCita = document.getElementById("form-cita");

    formCita.addEventListener("submit", function(event) {
        event.preventDefault();

        const cita = {
            fecha: document.getElementById("fecha").value,
            hora: document.getElementById("hora").value,
            nombreDueno: document.getElementById("nombre-dueno").value,
            telefono: document.getElementById("telefono").value,
            especie: document.getElementById("especie").value,
            nombreAnimal: document.getElementById("nombre-animal").value,
            edadAnimal: document.getElementById("edad-animal").value,
            raza: document.getElementById("raza").value,
            descripcion: document.getElementById("descripcion").value
        };

        fetch('/api/citas', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(cita)
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
            formCita.reset();
        })
        .catch(error => {
            console.error('Error al agendar la cita:', error);
        });
    });
});
