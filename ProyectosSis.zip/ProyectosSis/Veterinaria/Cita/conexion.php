<?php
$servername = "localhost"; // Cambia si tu servidor es diferente
$username = "root"; // Cambia si tu usuario es diferente
$password = ""; // Cambia si tienes una contraseña
$dbname = "veterinaria";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>