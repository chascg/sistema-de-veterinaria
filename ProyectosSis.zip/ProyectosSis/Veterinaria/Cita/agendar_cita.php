<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $nombre_dueno = $_POST['nombre_dueno'];
    $telefono = $_POST['telefono'];
    $especie = $_POST['especie'];
    $nombre_animal = $_POST['nombre_animal'];
    $edad_animal = $_POST['edad_animal'];
    $raza = $_POST['raza'];
    $descripcion = $_POST['descripcion'];

    $sql = "INSERT INTO citas (fecha, hora, nombre_dueno, telefono, especie, nombre_animal, edad_animal, raza, descripcion)
            VALUES ('$fecha', '$hora', '$nombre_dueno', '$telefono', '$especie', '$nombre_animal', $edad_animal, '$raza', '$descripcion')";

    if ($conn->query($sql) === TRUE) {
        echo "Cita agendada exitosamente";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
s