<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Puente servicios veterinaria</title>

    <script src="https://kit.fontawesome.com/c1df782baf.js"></script>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-thin-rounded/css/uicons-thin-rounded.css'>
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.1.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>
    <link rel="stylesheet" href="Inicio/css/styleUsuario.css">
    <style>
        /* Estilo para el navbar para evitar que se superponga */
        header {
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            background-color: white; /* Aseguramos que el navbar tenga fondo blanco */
        }

        /* Se agrega margen al cuerpo para que el contenido no quede cubierto por el navbar */
        body {
            margin-top: 70px;
        }

        ul li {
    font-size: 16px;
    color: #414247;
    margin: 15px 0; /* Espacio entre los elementos de la lista */
}


        /* Para pantallas más pequeñas, las columnas se apilan verticalmente */
        @media (max-width: 768px) {
            .general-1, .general-2 {
                width: 100%;
                margin-right: 0;
            }
        }

    </style>
</head>
<body> 

    <!-- Header Section -->
    <header>
        <div class="logo">
            <img src="Inicio/css/images/logo vet puente.jpeg" alt="Veterinaria Los Dos Becerros">
        </div>
        <nav class="navbar">
        <a href='inicio.php'>Inicio</a>
            <a href='Desc.php'>Descripción</a>
            <a href="http://localhost/ProyectosSis/Tienda-online/">Tienda</a>
            <a href='https://www.seccionamarilla.com.mx/informacion/puente-vazquez-victor-manuel-mvz/medicos-veterinarios-zootecnistas/tamaulipas/ciudad-mante/moderna/3396647'>Contacto</a>
        </nav>
    </header>

    <section class="general">

        <div class="general-1">
            <h2>Sobre Veterinaria Los Dos Becerros</h2>
            <p>
                Veterinaria Los Dos Becerros fue fundada en 2017 por Isidro Quintero Villanueva con el propósito de brindar atención integral a mascotas y animales de compañía. Nos hemos consolidado como un referente en el sector gracias a nuestro enfoque en ofrecer servicios médicos, quirúrgicos y estéticos, utilizando tecnología avanzada para diagnósticos y tratamientos.
            </p>
            <h2>Nuestra Misión</h2>
            <p>Garantizar el bienestar de los animales mediante una atención personalizada y utilizando tecnología. Nos esforzamos por brindar un servicio de calidad, innovador y accesible para todas las familias que confían en nosotros el cuidado de sus mascotas.</p>

            <h2>Nuestra Visión</h2>
            <p>Convertirnos en la clínica veterinaria líder en la región, destacándonos por nuestra dedicación, compromiso y capacidad para brindar soluciones eficientes para la salud de los animales. Buscamos ser un referente en el sector, con un enfoque centrado en la excelencia, la innovación y el bienestar animal.</p>
            <a href="#" class="btn-1"></a>
        </div>
        <div class="general-2"></div>
    </section>

    <section class="general">
        <div class="general-3"></div>
        <div class="general-1">
            <h2>Valores</h2>
            <ul>
                <li><strong>Compromiso:</strong> Nos dedicamos a ofrecer un servicio de calidad, buscando siempre el bienestar de los animales.</li>
                <li><strong>Innovación:</strong> Aplicamos tecnología de vanguardia para garantizar diagnósticos y tratamientos precisos.</li>
                <li><strong>Cercanía:</strong> Tratamos a cada mascota como parte de nuestra familia, con afecto y respeto.</li>
                <li><strong>Profesionalismo:</strong> Nuestro equipo está altamente capacitado en todas las áreas de la medicina veterinaria.</li>
            </ul>

            <h2>Propuesta de Sistema de Gestión</h2>
            <p>Estamos implementando un sistema de información avanzado que facilitará la gestión de clientes y mascotas, el agendamiento de citas y el manejo de tienda. Con este sistema, buscamos mejorar la eficiencia operativa y reducir la carga administrativa, lo que nos permitirá ofrecer una atención más ágil y de mayor calidad.</p>
            
            <a href="" class="btn-1"></a>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="footer">
        <div class="container container-footer">
            <div class="menu-footer">
                <div class="contact-info">
                    <p class="title-footer">Información de Contacto</p>
                    <ul>
                        <li>Dirección: Calle, 123</li>
                        <li>Teléfono: 000-000-0000</li>
                        <li>Dr. Veterinario: Isidro Quintero Torres</li>
                        <li>Email: vet@support.com</li>
                    </ul>
                    <div class="social-icons">
                        <span class="facebook">
                            <i class="fa-brands fa-facebook-f"></i>
                        </span>
                        <span class="twitter">
                            <i class="fa-brands fa-twitter"></i>
                        </span>
                        <span class="instagram">
                            <i class="fa-brands fa-instagram"></i>
                        </span>
                    </div>
                </div>

                <div class="information">
                    <p class="title-footer">Información</p>
                    <ul>
                        <li><a href="#">Acerca de Nosotros</a></li>
                        <li><a href="#">Políticas de Privacidad</a></li>
                        <li><a href="#">Términos y Condiciones</a></li>
                        <li><a href="#">Contáctanos</a></li>
                    </ul>
                </div>

                <div class="my-account">
                    <p class="title-footer">Mi cuenta</p>
                    <ul>
                        <li><a href="#">..</a></li>
                    </ul>
                </div>

                <div class="newsletter">
                    <p class="title-footer">Suscríbete a nuestro boletín</p>
                    <div class="content">
                        <p>Mantente al día con las novedades y promociones de Veterinaria Los Dos Becerros.</p>
                    </div>
                </div>
            </div>

            <div class="copyright">
                <p>Puente Servicios Veterinarios</p>
                <img src="productos/css/img/payment.png" alt="Métodos de pago">
            </div>
        </div>
    </footer>

    <script src="https://kit.fontawesome.com/81581fb069.js" crossorigin="anonymous"></script>
    <script src="Inicio/js/script.js"></script>

</body>
</html>